package com.sbt.bcamp.marketplace;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;

@RestController
public class HealthCheckController {
    @RequestMapping("/health/check")
    public @ResponseBody String check() {
        return "OK";
    }

    @RequestMapping("/info")
    public @ResponseBody
    String info() {
        HashMap<Long, Integer> information = new HashMap<>();

        Runtime runtime = Runtime.getRuntime();
        int numberOfProcessor = runtime.availableProcessors();
        information.put(runtime.freeMemory(), numberOfProcessor);

        return information.toString();

    }
}
