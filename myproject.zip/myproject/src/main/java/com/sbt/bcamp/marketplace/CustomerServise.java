package com.sbt.bcamp.marketplace;

import com.sbt.bcamp.customer.dto.CustomerDTO;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;


@Service
public class CustomerServise {

    private final RestTemplate restTemplate;

    public CustomerServise(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public CustomerDTO getCustomer(String login) {

        final String url = "http://10.36.128.215:8080/bcamp-customer/customers/";

//        RestTemplate restTemplate = new RestTemplate();
        CustomerDTO customer = restTemplate.getForObject(url + login, CustomerDTO.class);
        return customer;
    }


}
