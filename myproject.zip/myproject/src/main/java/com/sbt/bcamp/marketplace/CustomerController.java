package com.sbt.bcamp.marketplace;


import com.sbt.bcamp.customer.dto.CustomerDTO;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
public class CustomerController{

    private final CustomerServise customerServise;

    public CustomerController(CustomerServise customerServise) {
        this.customerServise = customerServise;
    }

    @RequestMapping(value = "/customers/{login}", method = RequestMethod.GET)
    public ResponseEntity<String> getCustomerInfo(@PathVariable String login) {
        ResponseEntity response;
        try{
            CustomerDTO customerDTO=customerServise.getCustomer(login);
            response = ResponseEntity.ok(customerDTO);
        }catch (Exception e){
            response = ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
        return response;

    }


}
