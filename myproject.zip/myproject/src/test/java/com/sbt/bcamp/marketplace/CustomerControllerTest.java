package com.sbt.bcamp.marketplace;


import com.fasterxml.jackson.databind.ObjectMapper;
import com.sbt.bcamp.customer.dto.CustomerDTO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;

import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.client.RestTemplate;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;



@RunWith(SpringRunner.class)
@WebMvcTest
public class CustomerControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private RestTemplate restTemplate;

    @Before
    public void setUp(){

        when(restTemplate.getForObject(anyString(), any())).thenReturn(CustomerDTO.class);

    }

    @Test
    public void customerReturnOK(){
        Assert.assertEquals("", "Мария", getCustomerDto().getFirstName());
    }

    CustomerDTO getCustomerDto() {
        CustomerDTO customer = new CustomerDTO();
        customer.setId(17777777);
        customer.setLogin("17777777");
        customer.setFirstName("Мария");
        customer.setLastName("Напорова");
        return customer;
    }
}


//    @Test
//    public void customerReturnOK() throws Exception {
//        mockMvc.perform(get("/customers/17467555")).andDo(print())
//                .andExpect(status().isOk())
//                .andExpect(content().string(is("{\"id\":27,\"login\":\"17502063\",\"firstName\":\"Мария\",\"lastName\":\"Напорова\",\"birthDate\":null}")));
//
//    }
//
//    @Test
//    public void customerReturnNotFound() throws Exception {
//        mockMvc.perform(get("/customers/0")).andDo(print())
//                .andExpect(status().isNotFound());
//
//    }





